# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

__license__   = 'GPL v3'
__copyright__ = '2011-2014, meme'
__docformat__ = 'restructuredtext en'

#####################################################################
# Help
#####################################################################

from calibre_plugins.kindle_collections.utilities import debug_print
from calibre.gui2 import info_dialog
from calibre_plugins.kindle_collections.__init__ import PLUGIN_NAME, PLUGIN_VERSION

#####################################################################

# Display help information
def run(parent):
    debug_print('BEGIN About')
    info = '<P>' + PLUGIN_NAME + ' ' + PLUGIN_VERSION
    dialog = info_dialog(parent.gui, _('About plugin'), _(info), '', show=True)
    debug_print('END About')
