# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-

__license__ = 'GPL 3'
__copyright__ = '2013, Saulius P. <saulius@kofmarai.net>'
__docformat__ = 'restructuredtext en'
