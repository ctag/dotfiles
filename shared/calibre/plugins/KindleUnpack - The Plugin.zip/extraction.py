# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import,
                        print_function)

__license__   = 'GPL v3'
__docformat__ = 'restructuredtext en'

import os, sys

#from calibre_plugins.kindleunpack_plugin import outputfix

from functools import partial

try:
    from PyQt5.Qt import QMenu, QToolButton
except ImportError:
    from PyQt4.Qt import QMenu, QToolButton

from calibre.gui2 import choose_dir, info_dialog, open_local_file
from calibre.gui2.actions import InterfaceAction

from calibre.ptempfile import PersistentTemporaryFile, PersistentTemporaryDirectory
from calibre_plugins.kindleunpack_plugin.__init__ import (PLUGIN_NAME,
                                PLUGIN_VERSION, PLUGIN_DESCRIPTION)
import calibre_plugins.kindleunpack_plugin.config as cfg
from calibre_plugins.kindleunpack_plugin.utilities import (get_icon, mobiProcessor,
                                set_plugin_icon_resources, showErrorDlg, topaz,
                                create_menu_item, create_menu_action_unique)


class InterfacePlugin(InterfaceAction):
    name = 'KindleUnpack'
    action_spec = ('KindleUnpack', None,
            _(PLUGIN_DESCRIPTION), None)
    popup_type = QToolButton.InstantPopup
    dont_add_to = frozenset(['menubar-device', 'toolbar-device', 'context-menu-device'])
    action_type = 'current'

    def genesis(self):
        self.menu = QMenu(self.gui)
        icon_resources = self.load_resources(cfg.PLUGIN_ICONS)
        set_plugin_icon_resources(cfg.PLUGIN_NAME, icon_resources)

        self.qaction.setMenu(self.menu)
        self.qaction.setIcon(get_icon(cfg.PLUGIN_ICONS[0]))
        # Setup hooks so that we only enable the relevant submenus for available formats for the selection.
        self.menu.aboutToShow.connect(self.about_to_show_menu)

    def findFormats(self, db, row):
        # Loop through the ebook's available formats and build a dictionary
        # of the mobi formats containing the format's path and encryption
        # status among other things.
        format_data = {}
        if not row.isValid():
            print ('Row not valid')
            return format_data
        self.book_id = book_id = self.gui.library_view.model().id(row)
        print ('Book ID {0}'.format(book_id))
        mobi_formats = ['MOBI', 'AZW', 'AZW3', 'AZW4', 'PRC']
        book_formats = db.formats(book_id, index_is_id=True, verify_formats=True)
        if not book_formats:
            print ('No book formats found.')
            book_formats = ''
        book_formats = book_formats.split(',')
        for format in book_formats:
            if format in mobi_formats:
                print (format)
                tmp_path = self.gui.library_view.model().db.format_abspath(
                                        book_id, format, index_is_id=True)
                # I believe that "verify_formats=True" in the db.formats function call
                # above should ensure that the format has a valid path, but just to be sure...
                if tmp_path:
                    print (tmp_path)
                    # Catch any topaz books lurking as AZWs
                    if topaz(tmp_path):
                        print ('Format {0} is a topaz file. Can\'t unpack.'.format(format))
                        format_data[format] = ('Topaz', 'Error')
                        tmp_path = None
                        continue
                    # Gather some preliminary details about the ebook.
                    try:
                        mobi = mobiProcessor(tmp_path)
                        entry = (tmp_path, mobi.isPrintReplica, mobi.hasKF8, mobi.isComboFile, mobi.isEncrypted)
                        format_data[format] = entry
                        tmp_path = None
                    except Exception, e:
                        print ('Error parsing format {0}: {1}'.format(format, str(e)))
                        format_data[format] = None
                        tmp_path = None
                        pass

        # Return dictionary of all MOBI formats for this book
        return format_data

    def update_db(self, bookfile, format):
        '''
        Update the calibre db with the extracted PDF
        '''
        if not self.gui.library_view.model().db.format_abspath(
                    self.book_id, format, index_is_id=True):
            current_idx = self.gui.library_view.currentIndex()
            stream = lopen(bookfile, 'rb')
            self.gui.library_view.model().db.add_format(self.book_id, format,
                    stream, index_is_id=True, replace=False, notify=True)
            if current_idx.isValid():
                self.gui.library_view.model().current_changed(current_idx, current_idx)
        else:
            raise Exception(_('The ' + format + ' already exists for this ebook in this library! ' +
                              'No attempt to overwrite it will be made.') )

    def directoryChooser(self):
        if cfg.plugin_prefs['Always_Use_Unpack_Folder']:
            return cfg.plugin_prefs['Unpack_Folder']
        else:
            return choose_dir(self.gui, _(PLUGIN_NAME + 'dir_chooser'),
                _('Select Directory To Unpack Kindle/Mobi Book To'))

    def show_configuration(self):
        self.interface_action_base_plugin.do_user_config(self.gui)

    def about_to_show_menu(self):
        db = self.gui.library_view.model().db
        row = self.gui.library_view.currentIndex()
        format_info = self.findFormats(db, row)
        m = self.menu
        m.clear()

        # Build the submenus on the fly based on the formats of the ebook
        # selected in the main library view.
        for format, value in format_info.items():
            if value:
                if value[0] == 'Topaz':
                    tool_tip = '{0} format is a Topaz book. Can\'t unpack.'.format(format)
                    mnu_msg = 'Can\'t unpack Topaz books.'
                    error_menu = create_menu_action_unique(self, m, _(mnu_msg)+'...', None, _(tool_tip),
                                            False, None)
                    error_menu.setEnabled(False)
                    continue
                mnu_img = 'drm-unlocked.png'
                mnu_tip = 'This {0} file is DRM-Free.'.format(format)
                if value[4]:
                    print ('isEncrypted = {0}'.format(str(value[4])))
                    mnu_tip = 'This {0} file has DRM... can\'t unpack.'.format(format)
                    mnu_img = 'drm-locked.png'
                ac = create_menu_item(self, m, _(format), mnu_img, _(mnu_tip), None)
                sm = QMenu()
                ac.setMenu(sm)
                tool_tip = 'Unpack the {0}\'s source components'.format(format)
                unpack_menu = create_menu_action_unique(self, sm, _('Unpack')+' {0}'.format(format), 'images/explode3.png', _(tool_tip),
                                             False, triggered=partial(self.unpack_ebook, value[0]))
                if value[4]:
                    unpack_menu.setEnabled(False)
                if value[1]:
                    tool_tip = 'Extract the PDF from the Print Replica format and add it to the library.'
                    preplica_menu = create_menu_action_unique(self, sm, _('Extract PDF')+'...', 'mimetypes/pdf.png', _(tool_tip),
                                                 False, triggered=partial(self.print_replica, value[0]))
                if value[3]:
                    tool_tip = 'Split the combo KF8/MOBI file into its two components.'
                    split_menu = create_menu_action_unique(self, sm, _('Split KF8/MOBI')+'...', 'edit-cut.png', _(tool_tip),
                                                 False, triggered=partial(self.combo_split, value[0]))
                convert_menu = None
                if value[2] or value[3]:
                    tool_tip = 'Convert standalone KF8 file to its original ePub.'
                    convert_menu = create_menu_action_unique(self, sm, _('KF8 to ePub')+'...', 'mimetypes/epub.png', _(tool_tip),
                                                 False, triggered=partial(self.convert_ebook, value[0]))
                if value[4] and convert_menu is not None:
                    convert_menu.setEnabled(False)
            else:
                tool_tip = 'Can\'t unpack this {0}.'.format(format)
                mnu_msg = 'Error encountered with {0} format.'.format(format)
                error_menu = create_menu_action_unique(self, m, _(mnu_msg)+'...', None, _(tool_tip),
                                            False, None)
                error_menu.setEnabled(False)
        if not format_info:
            tool_tip = 'No suitable format to unpack.'
            error_menu = create_menu_action_unique(self, m, _(tool_tip)+'...', None, _(tool_tip),
                                        False, None)
            error_menu.setEnabled(False)
        m.addSeparator()
        tool_tip = 'Configure the KindleUnpack plugin\'s settings.'
        create_menu_action_unique(self, m, _('Customize plugin')+'...', 'config.png', _(tool_tip),
                                  None, triggered=self.show_configuration)
        self.gui.keyboard.finalize()

    def unpack_ebook(self, path_to_mobi):
        outdir = self.directoryChooser()
        if outdir:
            try:
                mobiProcessor(path_to_mobi).unpackMOBI(outdir)
            except Exception, e:
                return showErrorDlg(str(e), self.gui, True)
            open_local_file(outdir)

    def convert_ebook(self, path_to_mobi):
        outdir = PersistentTemporaryDirectory()
        try:
            epubfile = mobiProcessor(path_to_mobi).unpackEPUB(outdir)
        except Exception, e:
            return showErrorDlg(str(e), self.gui, True)
        try:
            self.update_db(epubfile, 'EPUB')
        except Exception, e:
            return showErrorDlg(str(e), self.gui)
        return info_dialog(None, _(PLUGIN_NAME + ' v' + PLUGIN_VERSION),
            _('<p>ePub successfully unpacked and added to Library.'), show=True)

    def print_replica(self, path_to_mobi):
        outdir = PersistentTemporaryDirectory()
        pdffile = mobiProcessor(path_to_mobi).getPDFFile(outdir)
        try:
            self.update_db(pdffile, 'PDF')
        except Exception, e:
            return showErrorDlg(str(e), self.gui)
        return info_dialog(None, _(PLUGIN_NAME + ' v' + PLUGIN_VERSION),
            _('<p>PDF successfully extracted and added to Library.'), show=True)

    def combo_split(self, path_to_mobi):
        outdir = self.directoryChooser()
        if outdir:
            try:
                mobiProcessor(path_to_mobi).writeSplitCombo(outdir)
            except Exception, e:
                return showErrorDlg(str(e), self.gui, True)
            open_local_file(outdir)
