# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai
from __future__ import (unicode_literals, division, absolute_import,
                        print_function)

__license__   = 'GPL v3'
__docformat__ = 'restructuredtext en'


import os, sys, struct, re
from StringIO import StringIO
from traceback import print_exc

try:
    from PyQt5.Qt import QPixmap, QIcon
except ImportError:
    from PyQt4.Qt import QPixmap, QIcon
    
from calibre.utils.config import config_dir
from calibre.constants import iswindows
from calibre.gui2 import error_dialog
from calibre.gui2.actions import menu_action_unique_name
from calibre.gui2.keyboard import ShortcutConfig

import calibre_plugins.kindleunpack_plugin.kindleunpack.kindleunpack as _mu
from calibre_plugins.kindleunpack_plugin.kindleunpack.utf8_utils import utf8_str
from calibre_plugins.kindleunpack_plugin.kindleunpack.mobi_split import mobi_split

import calibre_plugins.kindleunpack_plugin.config as cfg
from calibre_plugins.kindleunpack_plugin.__init__ import (PLUGIN_NAME,
                    PLUGIN_VERSION, PLUGIN_DESCRIPTION)

plugin_name = None
plugin_icon_resources = {}

def set_plugin_icon_resources(name, resources):
    '''
    Set our global store of plugin name and icon resources for sharing between
    the InterfaceAction class which reads them and the ConfigWidget
    if needed for use on the customization dialog for this plugin.
    '''
    global plugin_icon_resources, plugin_name
    plugin_name = name
    plugin_icon_resources = resources

def get_icon(icon_name):
    '''
    Retrieve a QIcon for the named image from the zip file if it exists,
    or if not then from Calibre's image cache.
    '''
    if icon_name:
        pixmap = get_pixmap(icon_name)
        if pixmap is None:
            # Look in Calibre's cache for the icon
            return QIcon(I(icon_name))
        else:
            return QIcon(pixmap)
    return QIcon()

def get_pixmap(icon_name):
    '''
    Retrieve a QPixmap for the named image
    Any icons belonging to the plugin must be prefixed with 'images/'
    '''
    if not icon_name.startswith('images/'):
        # We know this is definitely not an icon belonging to this plugin
        pixmap = QPixmap()
        pixmap.load(I(icon_name))
        return pixmap

    # Check to see whether the icon exists as a Calibre resource
    # This will enable skinning if the user stores icons within a folder like:
    # ...\AppData\Roaming\calibre\resources\images\Plugin Name\
    if plugin_name:
        local_images_dir = get_local_images_dir(plugin_name)
        local_image_path = os.path.join(local_images_dir, icon_name.replace('images/', ''))
        if os.path.exists(local_image_path):
            pixmap = QPixmap()
            pixmap.load(local_image_path)
            return pixmap

    # As we did not find an icon elsewhere, look within our zip resources
    if icon_name in plugin_icon_resources:
        pixmap = QPixmap()
        pixmap.loadFromData(plugin_icon_resources[icon_name])
        return pixmap
    return None

def get_local_images_dir(subfolder=None):
    '''
    Returns a path to the user's local resources/images folder
    If a subfolder name parameter is specified, appends this to the path
    '''
    images_dir = os.path.join(config_dir, 'resources/images')
    if subfolder:
        images_dir = os.path.join(images_dir, subfolder)
    if iswindows:
        images_dir = os.path.normpath(images_dir)
    return images_dir

class SectionizerLight:
    """ Stolen from Mobi_Unpack and slightly modified. """
    def __init__(self, filename):
        self.data = open(filename, 'rb').read()
        if self.data[:3] == str('TPZ'):
            self.ident = 'TPZ'
        else:
            self.palmheader = self.data[:78]
            self.ident = self.palmheader[0x3C:0x3C+8]
        try:
            self.num_sections, = struct.unpack_from(str('>H'), self.palmheader, 76)
        except:
            return
        self.filelength = len(self.data)
        try:
            sectionsdata = struct.unpack_from(str('>%dL') % (self.num_sections*2), self.data, 78) + (self.filelength, 0)
            self.sectionoffsets = sectionsdata[::2]
        except:
            pass
    
    def loadSection(self, section):
        before, after = self.sectionoffsets[section:section+2]
        return self.data[before:after]

class MobiHeaderLight:
    """ Stolen from Mobi_Unpack and slightly modified. """
    def __init__(self, sect, sectNumber):
        self.sect = sect
        self.start = sectNumber
        self.header = self.sect.loadSection(self.start)
        self.records, = struct.unpack_from(str('>H'), self.header, 0x8)
        self.length, self.type, self.codepage, self.unique_id, self.version = struct.unpack(str('>LLLLL'), self.header[20:40])
        self.mlstart = self.sect.loadSection(self.start+1)[0:4]
        self.crypto_type, = struct.unpack_from(str('>H'), self.header, 0xC)
        
    def isEncrypted(self):
        return self.crypto_type != 0

    def isPrintReplica(self):
        return self.mlstart[0:4] == str('%MOP')

    def hasKF8(self):
        return self.start != 0 or self.version == 8
    
    def isJointFile(self):
        # Check for joint MOBI/KF8
        for i in xrange(len(self.sect.sectionoffsets)-1):
            before, after = self.sect.sectionoffsets[i:i+2]
            if (after - before) == 8:
                data = self.sect.loadSection(i)
                if data == str('BOUNDARY'):
                    return True
                    break
        return False

def showErrorDlg(errmsg, parent, trcbk=False):
    if trcbk:
        error= ''
        f=StringIO()
        print_exc(file=f)
        error_mess = f.getvalue().splitlines()
        for line in error_mess:
            error = error + str(line) + '\n'
        errmsg = errmsg + '\n\n' + error
    return  error_dialog(parent, _(PLUGIN_NAME + ' v' + PLUGIN_VERSION),
                _(errmsg), show=True)

def makeFileNames(prefix, infile, outdir, kf8=False):
    if kf8:
        return os.path.join(outdir, prefix+os.path.splitext(os.path.basename(infile))[0] + '.azw3')
    return os.path.join(outdir, prefix+os.path.splitext(os.path.basename(infile))[0] + '.mobi')


def topaz(f):
    return (file(f,'rb').read(3) == str('TPZ'))

def create_menu_item(ia, parent_menu, menu_text, image=None, tooltip=None,
                     shortcut=(), triggered=None, is_checked=None):
    '''
    Create a menu action with the specified criteria and action
    Note that if no shortcut is specified, will not appear in Preferences->Keyboard
    This method should only be used for actions which either have no shortcuts,
    or register their menus only once. Use create_menu_action_unique for all else.
    '''
    if shortcut is not None:
        if len(shortcut) == 0:
            shortcut = ()
        else:
            shortcut = _(shortcut)
    ac = ia.create_action(spec=(menu_text, None, tooltip, shortcut),
        attr=menu_text)
    if image:
        ac.setIcon(get_icon(image))
    if triggered is not None:
        ac.triggered.connect(triggered)
    if is_checked is not None:
        ac.setCheckable(True)
        if is_checked:
            ac.setChecked(True)

    parent_menu.addAction(ac)
    return ac

def create_menu_action_unique(ia, parent_menu, menu_text, image=None, tooltip=None,
                       shortcut=None, triggered=None, is_checked=None, shortcut_name=None,
                       unique_name=None):
    '''
    Create a menu action with the specified criteria and action, using the new
    InterfaceAction.create_menu_action() function which ensures that regardless of
    whether a shortcut is specified it will appear in Preferences->Keyboard
    '''
    orig_shortcut = shortcut
    kb = ia.gui.keyboard
    if unique_name is None:
        unique_name = menu_text
    if not shortcut == False:
        full_unique_name = menu_action_unique_name(ia, unique_name)
        if full_unique_name in kb.shortcuts:
            shortcut = False
        else:
            if shortcut is not None and not shortcut == False:
                if len(shortcut) == 0:
                    shortcut = None
                else:
                    shortcut = _(shortcut)

    if shortcut_name is None:
        shortcut_name = menu_text.replace('&','')

    ac = ia.create_menu_action(parent_menu, unique_name, menu_text, icon=None, shortcut=shortcut,
        description=tooltip, triggered=triggered, shortcut_name=shortcut_name)
    if shortcut == False and not orig_shortcut == False:
        if ac.calibre_shortcut_unique_name in ia.gui.keyboard.shortcuts:
            kb.replace_action(ac.calibre_shortcut_unique_name, ac)
    if image:
        ac.setIcon(get_icon(image))
    if is_checked is not None:
        ac.setCheckable(True)
        if is_checked:
            ac.setChecked(True)
    return ac

class mobiProcessor:
    def __init__(self, infile):
        self.infile = infile
        self.sect = SectionizerLight(self.infile)
        if self.sect.ident != 'BOOKMOBI' and self.sect.ident != 'TEXtREAd':
            raise Exception(_('Unrecognized Kindle/MOBI file format!'))
        mhl = MobiHeaderLight(self.sect, 0)
        self.version = mhl.version
        self.isEncrypted = mhl.isEncrypted()
        if self.sect.ident == 'TEXtREAd':
            self.isPrintReplica = False
            self.isComboFile = False
            self.hasKF8 = False
            return
        self.isPrintReplica = mhl.isPrintReplica()
        self.hasKF8 = mhl.hasKF8()
        self.isComboFile = mhl.isJointFile()
        self.ePubVersion = cfg.plugin_prefs['Epub_Version']
        self.useHDImages = cfg.plugin_prefs['Use_HD_Images']

    def getPDFFile(self, outdir):
        mu = _mu.unpackBook(self.infile, outdir)
        files = os.listdir(outdir)
        pdf = ''
        filefilter = re.compile('\.pdf$', re.IGNORECASE)
        files = filter(filefilter.search, files)
        if files:
            for filename in files:
                pdf = os.path.join(outdir, filename)
                break
        else:
            raise Exception(_('Problem locating unpacked pdf.'))
        if pdf=='':
            raise Exception(_('Problem locating unpacked pdf.'))
        if not os.path.exists(pdf):
            raise Exception(_('Problem locating unpacked pdf: {0}'.format(pdf)))
        return pdf

    def unpackMOBI(self, outdir):
        mu = _mu.unpackBook(self.infile, outdir, epubver=self.ePubVersion, use_hd=self.useHDImages)

    def unpackEPUB(self, outdir):
        mu = _mu.unpackBook(self.infile, outdir, epubver=self.ePubVersion, use_hd=self.useHDImages)
        kf8dir = os.path.join(outdir, 'mobi8')
        kf8BaseName = os.path.splitext(os.path.basename(self.infile))[0]
        epub = os.path.join(kf8dir, '{0}.epub'.format(kf8BaseName))
        if not os.path.exists(epub):
            raise Exception(_('Problem locating unpacked epub: {0}'.format(epub)))
        return epub

    def writeSplitCombo(self, outdir):
        mobi_to_split = mobi_split(utf8_str(self.infile))
        outMobi = makeFileNames('MOBI-', self.infile, outdir)
        outKF8 = makeFileNames('KF8-', self.infile, outdir, True)
        file(outMobi, 'wb').write(mobi_to_split.getResult7())
        file(outKF8, 'wb').write(mobi_to_split.getResult8())
